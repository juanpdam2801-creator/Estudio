package com.docencia.herencia.ejercicio9;

import java.util.UUID;

public class Electronica extends Producto {

    private int garantiaMeses;
    public  Electronica(UUID id){
        super(id);
    }

    public Electronica(UUID id, String nombre, double precio, int garantiaMeses) {
        super(id, nombre, precio);
        this.garantiaMeses = garantiaMeses;
}

    public int getGarantiaMeses() { return garantiaMeses; }

    @Override
    public String categoria() {
        return "Electronica";
    }

     @Override
    public String toString() {
        return "{Electronica " + getId()
                + " isbn='" + getGarantiaMeses() + " id=" + getId()
                + "}";
    }
     @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
    if (!(obj instanceof Electronica)) {
        return false;
    }
        return super.equals(obj);
    }
}
