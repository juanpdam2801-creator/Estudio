package com.docencia.interfaces.ejercicio2;

import java.util.Objects;
import java.util.UUID;

/**
 * Implementacion concreta de Volador.
 */
public class Avion implements Volador {

    private UUID id;
    private String modelo;
    private int motores;

    public Avion(UUID id) {
        this.id = id;
    }
    public Avion(UUID id, String modelo, int motores) {
        this.id = id == null ? UUID.randomUUID() : id;
        this.modelo = modelo;
        this.motores = motores;
    }

    

    public UUID getId() {
        return id;
    }

    public String getModelo() {
        return modelo;
    }

    public int getMotores() {
        return motores;
    }

    @Override
    public int altitudMaxima() {
        return 12000;
    }


    @Override
    public int hashCode() {
        int hash = 5;
        hash = 29 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        final Avion other = (Avion) obj;
        return Objects.equals(this.id, other.id);
    }

    @Override
    public String toString() {
        return "{Avion" +
            " id='" + getId() + "'" +
            ", modelo='" + getModelo() + "'" +
            ", motores='" + getMotores() + "'" +
            "}";
    }

}
