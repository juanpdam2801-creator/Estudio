package com.docencia.interfaces.ejercicio6;

import java.util.Objects;
import java.util.UUID;

/**
 * Implementacion concreta de Autenticable.
 */
public class Admin implements Autenticable {

    private UUID id;
    private String nombre;
    private String hash;
    public Admin(UUID id) {
            this.id = id;
        }
    public Admin(UUID id, String nombre, String hash) {
         this.id = id == null ? UUID.randomUUID() : id;
         this.hash = hash;
         this.nombre = nombre;
    }

    

    public UUID getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getHash() {
        return hash;
    }

    @Override
    public boolean autenticar(String clave) {
        return clave != null && clave.equals(hash);
    }

    

    @Override
    public String toString() {
        return "{Admin" +
            " id='" + getId() + "'" +
            ", nombre='" + getNombre() + "'" +
            ", hash='" + getHash() + "'" +
            "}";
    }
    

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 79 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Admin other = (Admin) obj;
        return Objects.equals(this.id, other.id);
    }
}
