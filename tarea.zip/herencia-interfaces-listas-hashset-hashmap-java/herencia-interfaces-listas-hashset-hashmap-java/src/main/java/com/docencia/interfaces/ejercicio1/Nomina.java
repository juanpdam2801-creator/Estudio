package com.docencia.interfaces.ejercicio1;

import java.util.Objects;
import java.util.UUID;

/**
 * Implementacion concreta de Pagable.
 */
public class Nomina implements Pagable {

    private UUID id;
    private double bruto;
    private double retencion;


    public Nomina(UUID id){
        this.id = id;
    }


    public Nomina(UUID id, double bruto, double retencion) {
        this.id = id == null ? UUID.randomUUID() : id;
        this.bruto = bruto;
        this.retencion = retencion;
    }

    public UUID getId() {
        return id;
    }

    public double getBruto() {
        return bruto;
    }

    public double getRetencion() {
        return retencion;
    }

    @Override
    public double total() {
        return bruto - (bruto * retencion);
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 23 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        final Nomina other = (Nomina) obj;
        return Objects.equals(this.id, other.id);
    }

    @Override
    public String toString() {
        return "{Nomina " +getClass()+
            " id='" + getId() + "'" +
            ", bruto='" + getBruto() + "'" +
            ", retencion='" + getRetencion() + "'" +
            "}";
    }

}
