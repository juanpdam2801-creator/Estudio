package com.docencia.herencia.ejercicio7;

import java.util.UUID;

public class Telefono extends Dispositivo {

    private String numero;


    public Telefono(UUID id){
        super(id);
    }
    public Telefono(UUID id, String fabricante, String numero) {
        super(id, fabricante);
        this.numero = numero;
}

    public String getNumero() { return numero; }

    @Override
    public String tipo() {
        return "Telefono";
    }

   @Override
    public String toString() {
        return "{Telefono " + getClass() + " id= " + getId()
                + " pulgadas='" + getNumero() + "'"
                + "}";
    }
     @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
    if (!(obj instanceof Telefono)) {
        return false;
    }
        return super.equals(obj);
    }
}
