package com.docencia.listas.ejercicio9;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.UUID;

import com.docencia.herencia.ejercicio9.Libro;
import com.docencia.herencia.ejercicio9.Producto;

/**
 * Gestiona una lista de {@link Producto} usando {@link java.util.ArrayList}.
 *
 * Reglas:
 * - No se permiten elementos nulos.
 * - No se permiten productos con nombre nulo o en blanco.
 * - No se permiten precios negativos.
 * - No se permiten ids nulos ni duplicados dentro de la lista.
 */
public class ListaProductos {

    private final List<Producto> productos = new ArrayList<>();

    public void anadir(Producto producto) {
      if (productos.contains(producto)) {
            throw new IllegalArgumentException();
        }
        validar(producto);
        productos.add(producto);
    }

    public Producto buscarPorId(UUID id) {
     if (id == null) {
            throw new IllegalArgumentException();
        }
        Producto ProductoBuscar = new Libro(id);
        for (Producto producto : productos) {
            if (producto.equals(ProductoBuscar)) {
                return producto;
            }
        }
        return null;
    }

    public boolean eliminarPorId(UUID id) {
      Producto producto = buscarPorId(id);
        if (producto == null) {
            return false;
        }
        return productos.remove(producto);

    }

    public void modificar(UUID id, Producto nuevoProducto) {
     Producto existente = buscarPorId(id);
        if (existente == null) {
            throw new NoSuchElementException();
        }
        validar(nuevoProducto);
        if (!existente.equals(nuevoProducto)) {
            throw new IllegalArgumentException();
        }
        productos.remove(existente);
        productos.add(nuevoProducto);
    }

    public List<Producto> listar() {
     return List.copyOf(productos);
    }

    public int tamanio() {
     return productos.size();
    }

    private boolean existeId(UUID id) {
        return productos.stream().anyMatch(p -> p.getId().equals(id));
    }

    private void validar(Producto producto) {
        if (producto == null) {
            throw new IllegalArgumentException("El producto no puede ser nulo");
        }
        if (producto.getId() == null) {
            throw new IllegalArgumentException("El id no puede ser nulo");
        }
        if (producto.getNombre() == null || producto.getNombre().isBlank()) {
            throw new IllegalArgumentException("El nombre no puede ser nulo o en blanco");
        }
        if (producto.getPrecio() < 0) {
            throw new IllegalArgumentException("El precio no puede ser negativo");
        }
    }
}
