package com.docencia.interfaces.ejercicio1;

import java.util.Objects;
import java.util.UUID;

/**
 * Implementacion concreta de Pagable.
 */
public class Factura implements Pagable {

    private UUID id;
    private double base;
    private double iva;

    public Factura(UUID id){
      this.id = id;
    }

    public Factura(UUID id, double base, double iva) {
        this.id = id == null ? UUID.randomUUID() : id;
        this.base = base;
        this.iva = iva;
    }

    public UUID getId() {
        return id;
    }

    public double getBase() {
        return base;
    }

    public double getIva() {
        return iva;
    }

    @Override
    public double total() {
        return base + (base * iva);
    }


    @Override
    public int hashCode() {
        int hash = 3;
        hash = 97 * hash + Objects.hashCode(this.id);
        return hash;
    }

   

    

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
       }
        final Factura other = (Factura) obj;
        return Objects.equals(this.id, other.id);
    }
@Override
    public String toString() {
        return "{Factura " +getClass()+
            " id='" + getId() + "'" +
            ", base='" + getBase() + "'" +
            ", iva='" + getIva() + "'" +
            "}";
    }
}
