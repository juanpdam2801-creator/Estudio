package com.docencia.interfaces.ejercicio4;

import java.util.Objects;
import java.util.UUID;

/**
 * Implementacion concreta de Reproducible.
 */
public class Cancion implements Reproducible {

    private UUID id;
    private String titulo;
    private String artista;

    public Cancion(UUID id) {
        this.id = id;
    }

    public Cancion(UUID id, String titulo, String artista) {
        this.id = id == null ? UUID.randomUUID() : id;
        this.titulo = titulo;
        this.artista = artista;
    }

    public UUID getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getArtista() {
        return artista;
    }

    @Override
    public String reproducir() {
        return "Reproduciendo cancion: " + titulo;
    }

    

    @Override
    public String toString() {
        return "{Cancion" +
            " id='" + getId() + "'" +
            ", titulo='" + getTitulo() + "'" +
            ", artista='" + getArtista() + "'" +
            "}";
    }

   
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 41 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Cancion other = (Cancion) obj;
        return Objects.equals(this.id, other.id);
    }
}
