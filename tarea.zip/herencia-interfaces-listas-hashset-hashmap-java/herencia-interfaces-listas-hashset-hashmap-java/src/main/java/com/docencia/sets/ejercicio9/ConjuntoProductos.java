package com.docencia.sets.ejercicio9;


import java.util.HashSet;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.UUID;

import com.docencia.herencia.ejercicio9.Libro;
import com.docencia.herencia.ejercicio9.Producto;

/**
 * Gestiona un conjunto de {@link Producto} usando internamente {@link HashSet}.
 *
 * Reglas:
 * - No se permiten elementos nulos.
 * - No se permiten elementos con campos "vacios" segun la validacion del ejercicio.
 * - No se permiten ids nulos ni duplicados.
 */
public class ConjuntoProductos {

    private final Set<Producto> set = new HashSet<>();

    /** Anad... un elemento a la coleccion. */
    public void anadir(Producto elemento) {
         if (set.contains(elemento)) {
            throw new IllegalArgumentException();
        }
        validar(elemento);
        set.add(elemento);
    }

    /** Busca por id. */
public Producto buscarPorId(UUID id) {
    if (id == null) {
            throw new IllegalArgumentException();
        }
        Producto ProductoBuscar = new Libro(id);
        for (Producto Producto : set) {
            if (Producto.equals(ProductoBuscar)) {
                return Producto;
            }
        }
        return null;
}

    /** Elimina por id. */
    public boolean eliminarPorId(UUID id) {
       Producto Producto = buscarPorId(id);
        if (Producto == null) {
            return false;
        }
        return set.remove(Producto);
    }

    /** Reemplaza el elemento con ese id por otro (mismo id). */
    public void modificar(UUID id, Producto nuevoElemento) {
        Producto existente = buscarPorId(id);
        if (existente == null) {
            throw new NoSuchElementException();
        }
        validar(nuevoElemento);
        if (!existente.equals(nuevoElemento)) {
            throw new IllegalArgumentException();
        }
        set.remove(existente);
        set.add(nuevoElemento);
    }

    /** Devuelve una copia inmutable del conjunto. */
    public Set<Producto> listar() {
       return Set.copyOf(set);
    }

    public int tamanio() {
       return set.size();
    }
    private void validar(Producto elemento) {
        if (elemento == null) {
            throw new IllegalArgumentException("El producto no puede ser nulo");
        }
        if (elemento.getId() == null) {
            throw new IllegalArgumentException("El id no puede ser nulo");
        }
        if (elemento.getNombre() == null || elemento.getNombre().isBlank()) {
            throw new IllegalArgumentException("El nombre no puede ser nulo o en blanco");
        }
        if (elemento.getPrecio() < 0) {
            throw new IllegalArgumentException("El precio no puede ser negativo");
        }
    }

}
