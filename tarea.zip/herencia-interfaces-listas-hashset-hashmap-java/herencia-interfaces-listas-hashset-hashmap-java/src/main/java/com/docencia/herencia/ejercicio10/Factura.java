package com.docencia.herencia.ejercicio10;

import java.util.UUID;

public class Factura extends Documento {

    private String numero;


    public Factura(UUID id){
        super(id);
    }

    public Factura(UUID id, String titulo, String numero) {
        super(id, titulo);
        this.numero = numero;
}

    public String getNumero() { return numero; }

    @Override
    public String tipo() {
        return "Factura";
    }

    @Override
    public String toString() {
        return "{Contrato" +getClass()+
            " numero='" + getNumero() + "id=" +getId()+
            "}";
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
    if (!(obj instanceof  Factura)) {
        return false;
    }
        return super.equals(obj);
    }
    
}
