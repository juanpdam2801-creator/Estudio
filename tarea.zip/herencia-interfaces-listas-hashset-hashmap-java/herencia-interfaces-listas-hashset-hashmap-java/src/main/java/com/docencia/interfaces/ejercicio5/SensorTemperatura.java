package com.docencia.interfaces.ejercicio5;

import java.util.Objects;
import java.util.UUID;

/**
 * Implementacion concreta de Medible.
 */
public class SensorTemperatura implements Medible {

    private UUID id;
    private String ubicacion;
    private double celsius;
    public SensorTemperatura(UUID id) {
            this.id = id;
        }
    public SensorTemperatura(UUID id, String ubicacion, double celsius) {
        this.id = id == null ? UUID.randomUUID() : id;
        this.ubicacion = ubicacion;
        this.celsius = celsius;
    }

    

    public UUID getId() {
        return id;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public double getCelsius() {
        return celsius;
    }

    @Override
    public double medir() {
        return celsius;
    }


    @Override
    public String toString() {
        return "{SensorTemperatura" +
            " id='" + getId() + "'" +
            ", ubicacion='" + getUbicacion() + "'" +
            ", celsius='" + getCelsius() + "'" +
            "}";
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 19 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final SensorTemperatura other = (SensorTemperatura) obj;
        return Objects.equals(this.id, other.id);
    }
}
