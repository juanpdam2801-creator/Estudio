package com.docencia.herencia.ejercicio4;

import java.util.UUID;

public class Gato extends Animal {

    private boolean cazador;

    public Gato(UUID id) {
        super(id);
    }

    public Gato(UUID id, String nombre, boolean cazador) {
        super(id, nombre);
        this.cazador = cazador;
    }

    public boolean getCazador() {
        return cazador;
    }

    @Override
    public String sonido() {
        return "Miau";
    }

    @Override
    public String toString() {
        return "{Gato" + getNombre()
                + " cazador='" + getCazador() + "id=" + getId()
                + "}";
    }

 @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
    if (!(obj instanceof Gato)) {
        return false;
    }
        return super.equals(obj);
    }

}
