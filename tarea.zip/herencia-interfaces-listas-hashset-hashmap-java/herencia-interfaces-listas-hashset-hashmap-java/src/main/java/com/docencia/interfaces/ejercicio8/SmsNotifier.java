package com.docencia.interfaces.ejercicio8;

import java.util.Objects;
import java.util.UUID;

/**
 * Implementacion concreta de Notificable.
 */
public class SmsNotifier implements Notificable {

    private UUID id;
    private String numero;
    private String proveedor;
    public SmsNotifier(UUID id) {
            this.id = id;
        }
    public SmsNotifier(UUID id, String numero, String proveedor) {
           this.id = id == null ? UUID.randomUUID() : id;
           this.numero = numero;
           this.proveedor = proveedor;
    }

    

    public UUID getId() {
        return id;
    }

    public String getNumero() {
        return numero;
    }

    public String getProveedor() {
        return proveedor;
    }

    @Override
    public boolean notificar(String mensaje) {
        return mensaje != null && !mensaje.isBlank() && numero != null && numero.length() >= 6;
    }


    @Override
    public String toString() {
        return "{SmsNotifier" +
            " id='" + getId() + "'" +
            ", numero='" + getNumero() + "'" +
            ", proveedor='" + getProveedor() + "'" +
            "}";
    }
    
    
    @Override
    public int hashCode() {
        int hash = 3;
        hash = 37 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final SmsNotifier other = (SmsNotifier) obj;
        return Objects.equals(this.id, other.id);
    }
}
