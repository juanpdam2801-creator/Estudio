package com.docencia.interfaces.ejercicio7;

import java.util.Objects;
import java.util.UUID;

/**
 * Implementacion concreta de Exportable.
 */
public class JsonExporter implements Exportable {

    private UUID id;
    private boolean pretty;
    private int indent;

    public JsonExporter(UUID id, boolean pretty, int indent) {
        this.id = id == null ? UUID.randomUUID() : id;
        this.indent = indent;
        this.pretty = pretty;
    }

    public UUID getId() {
        return id;
    }

    public boolean getPretty() {
        return pretty;
    }

    public int getIndent() {
        return indent;
    }

    @Override
    public String exportar() {
        return pretty ? "JSON(pretty)" : "JSON";
    }


    @Override
    public String toString() {
        return "{JsonExporter" +
            " id='" + getId() + "'" +
            ", pretty='" + getPretty() + "'" +
            ", indent='" + getIndent() + "'" +
            "}";
    }
    

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 89 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final JsonExporter other = (JsonExporter) obj;
        return Objects.equals(this.id, other.id);
    }
}
