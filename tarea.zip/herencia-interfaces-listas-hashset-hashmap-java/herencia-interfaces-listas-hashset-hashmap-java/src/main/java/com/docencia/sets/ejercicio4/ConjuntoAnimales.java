package com.docencia.sets.ejercicio4;


import java.util.HashSet;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.UUID;

import com.docencia.herencia.ejercicio4.Animal;
import com.docencia.herencia.ejercicio4.Perro;

/**
 * Gestiona un conjunto de {@link Animal} usando internamente {@link HashSet}.
 *
 * Reglas:
 * - No se permiten elementos nulos.
 * - No se permiten elementos con campos "vacios" segun la validacion del ejercicio.
 * - No se permiten ids nulos ni duplicados.
 */
public class ConjuntoAnimales {

    private final Set<Animal> set = new HashSet<>();

    /** Anad... un elemento a la coleccion. */
    public void anadir(Animal elemento) {
        if (set.contains(elemento)) {
            throw new IllegalArgumentException();
        }
        validar(elemento);
        set.add(elemento);
    }

    /** Busca por id. */
public Animal buscarPorId(UUID id) {
     if (id == null) {
            throw new IllegalArgumentException();
        }
        Animal animalBuscar = new Perro(id);
        for (Animal animal : set) {
            if (animal.equals(animalBuscar)) {
                return animal;
            }
        }
        return null;
}

    /** Elimina por id. */
    public boolean eliminarPorId(UUID id) {
         Animal animal = buscarPorId(id);
        if (animal == null) {
            return false;
        }
        return set.remove(animal);
    }

    /** Reemplaza el elemento con ese id por otro (mismo id). */
    public void modificar(UUID id, Animal nuevoElemento) {
         Animal existente = buscarPorId(id);
        if (existente == null) {
            throw new NoSuchElementException();
        }
        validar(nuevoElemento);
        if (!existente.equals(nuevoElemento)) {
            throw new IllegalArgumentException();
        }
        set.remove(existente);
        set.add(nuevoElemento);
    }

    /** Devuelve una copia inmutable del conjunto. */
    public Set<Animal> listar() {
        return Set.copyOf(set);
    }

    public int tamanio() {
        return set.size();
    }
    
    private void validar(Animal elemento) {
        if (elemento == null) {
            throw new IllegalArgumentException("El animal no puede ser nulo");
        }
        if (elemento.getId() == null) {
            throw new IllegalArgumentException("El id no puede ser nulo");
        }
        if (elemento.getNombre() == null || elemento.getNombre().isBlank()) {
            throw new IllegalArgumentException("El nombre no puede ser nulo o en blanco");
        }
    }

}
