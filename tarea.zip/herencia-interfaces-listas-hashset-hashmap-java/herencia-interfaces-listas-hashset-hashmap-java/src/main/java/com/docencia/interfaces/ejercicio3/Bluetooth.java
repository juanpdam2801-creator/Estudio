package com.docencia.interfaces.ejercicio3;

import java.util.Objects;
import java.util.UUID;

/**
 * Implementacion concreta de Conectable.
 */
public class Bluetooth implements Conectable {

    private UUID id;
    private String mac;
    private int canal;

     public Bluetooth(UUID id) {
        this.id = id;
    }

    public Bluetooth(UUID id, String mac, int canal) {
         this.id = id == null ? UUID.randomUUID() : id;
         this.mac = mac;
         this.canal = canal;
    }

   

    public UUID getId() {
        return id;
    }

    public String getMac() {
        return mac;
    }

    public int getCanal() {
        return canal;
    }

    @Override
    public boolean conectar(String destino) {
        return destino != null && destino.contains(":");
    }



    @Override
    public int hashCode() {
        int hash = 7;
        hash = 89 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Bluetooth other = (Bluetooth) obj;
        return Objects.equals(this.id, other.id);
    }

    @Override
    public String toString() {
        return "{Bluetooth" +
            " id='" + getId() + "'" +
            ", mac='" + getMac() + "'" +
            ", canal='" + getCanal() + "'" +
            "}";
    }

}
