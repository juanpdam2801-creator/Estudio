package com.docencia.herencia.ejercicio8;

import java.util.UUID;

public class PagoTarjeta extends Pago {

    private String ultimos4;

    public PagoTarjeta(UUID id){
        super(id);
    }

    public PagoTarjeta(UUID id, double importe, String ultimos4) {
        super(id, importe);
        this.ultimos4 = ultimos4;
}

    public String getUltimos4() { return ultimos4; }

    @Override
    public boolean requiereValidacion() {
        return true;
    }

    @Override
    public String toString() {
        return "{Pago Tarjeta " +getClass()+ " id= "+getId()+
            " entregado='" + getUltimos4() + "importe=" +getImporte()+
            "}";
    }
     @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
    if (!(obj instanceof PagoTarjeta)) {
        return false;
    }
        return super.equals(obj);
    }
}
