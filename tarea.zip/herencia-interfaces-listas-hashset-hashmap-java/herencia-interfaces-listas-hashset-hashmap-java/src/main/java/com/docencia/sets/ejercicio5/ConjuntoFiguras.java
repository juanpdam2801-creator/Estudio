package com.docencia.sets.ejercicio5;


import java.util.HashSet;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.UUID;

import com.docencia.herencia.ejercicio5.Circulo;
import com.docencia.herencia.ejercicio5.Figura;

/**
 * Gestiona un conjunto de {@link Figura} usando internamente {@link HashSet}.
 *
 * Reglas:
 * - No se permiten elementos nulos.
 * - No se permiten elementos con campos "vacios" segun la validacion del ejercicio.
 * - No se permiten ids nulos ni duplicados.
 */
public class ConjuntoFiguras {

    private final Set<Figura> set = new HashSet<>();

    /** Anad... un elemento a la coleccion. */
    public void anadir(Figura elemento) {
         if (set.contains(elemento)) {
            throw new IllegalArgumentException();
        }
        validar(elemento);
        set.add(elemento);
    }

    /** Busca por id. */
public Figura buscarPorId(UUID id) {
    if (id == null) {
            throw new IllegalArgumentException();
        }
        Figura figuraBuscar = new Circulo(id);
        for (Figura figura : set) {
            if (figura.equals(figuraBuscar)) {
                return figura;
            }
        }
        return null;
}

    /** Elimina por id. */
    public boolean eliminarPorId(UUID id) {
          Figura figura = buscarPorId(id);
        if (figura == null) {
            return false;
        }
        return set.remove(figura);
    }

    /** Reemplaza el elemento con ese id por otro (mismo id). */
    public void modificar(UUID id, Figura nuevoElemento) {
         Figura existente = buscarPorId(id);
        if (existente == null) {
            throw new NoSuchElementException();
        }
        validar(nuevoElemento);
        if (!existente.equals(nuevoElemento)) {
            throw new IllegalArgumentException();
        }
        set.remove(existente);
        set.add(nuevoElemento);
    }

    /** Devuelve una copia inmutable del conjunto. */
    public Set<Figura> listar() {
          return Set.copyOf(set);
    }

    public int tamanio() {
         return set.size();
    }
    private void validar(Figura elemento) {
        if (elemento == null) {
            throw new IllegalArgumentException("La figura no puede ser nula");
        }
        if (elemento.getId() == null) {
            throw new IllegalArgumentException("El id no puede ser nulo");
        }
        if (elemento.getColor() == null || elemento.getColor().isBlank()) {
            throw new IllegalArgumentException("El color no puede ser nulo o en blanco");
        }
    }

}
