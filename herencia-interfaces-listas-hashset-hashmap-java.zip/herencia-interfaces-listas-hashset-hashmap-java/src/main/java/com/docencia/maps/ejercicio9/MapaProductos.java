package com.docencia.maps.ejercicio9;

import com.docencia.herencia.ejercicio9.Producto;

import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.UUID;

/**
 * Gestiona un mapa de {@link Producto} usando internamente {@link HashMap}.
 *
 * Reglas:
 * - No se permiten elementos nulos.
 * - No se permiten elementos con campos "vacios" segun la validacion del ejercicio.
 * - No se permiten ids nulos ni duplicados.
 */
public class MapaProductos {
    private final Map<UUID, Producto> index = new HashMap<>();

    /** Anad... un elemento a la coleccion. */
    public void anadir(Producto elemento) {
        validar(elemento);
        Producto existe = buscarPorId(elemento.getId());
        if (existe != null) {
            throw new IllegalArgumentException();
        }
        index.put(elemento.getId(), elemento);
    }

    /** Busca por id. */
    public Producto buscarPorId(UUID id) {
        if (id == null) {
            throw new IllegalArgumentException();
        }
        boolean existe = index.containsKey(id);
        if (!existe) {
            return null;
        }
         return index.get(id);
    }
    /** Elimina por id. */
    public boolean eliminarPorId(UUID id) {
        index.remove(id);
        return true;
    }

    /** Reemplaza el elemento con ese id por otro (mismo id). */
    public void modificar(UUID id, Producto nuevoElemento) {
        Producto producto = buscarPorId(id);
        if (producto == null) {
            throw new NoSuchElementException();
        }
        validar(nuevoElemento);
        if (!(producto.equals(nuevoElemento))) {
            throw new IllegalArgumentException();
        }
        index.replace(id, producto, nuevoElemento);
    }

    /** Devuelve una copia inmutable del conjunto. */
    public java.util.Set<Producto> listar() {
        return Set.copyOf(index.values());
    }

    public int tamanio() {
        return index.size();
    }
    private void validar(Producto elemento) {
        if (elemento == null) {
            throw new IllegalArgumentException("El producto no puede ser nulo");
        }
        if (elemento.getId() == null) {
            throw new IllegalArgumentException("El id no puede ser nulo");
        }
        if (elemento.getNombre() == null || elemento.getNombre().isBlank()) {
            throw new IllegalArgumentException("El nombre no puede ser nulo o en blanco");
        }
        if (elemento.getPrecio() < 0) {
            throw new IllegalArgumentException("El precio no puede ser negativo");
        }
    }

}
