package com.docencia.herencia.ejercicio5;

import java.util.UUID;

public class Circulo extends Figura {

    private double radio;


    public  Circulo(UUID id){
        super(id);
    }
    public Circulo(UUID id, String color, double radio) {
        super(id, color);
        this.radio = radio;
}

    public double getRadio() { return radio; }

    @Override
    public double area() {
        return Math.PI * getRadio() * getRadio();
    }


    @Override
    public String toString() {
        return "{ Circulo : " +
            " radio='" + getRadio() + " id= " + getId()+
            "}";
    }
     @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
    if (!(obj instanceof Circulo)) {
        return false;
    }
        return super.equals(obj);
    }
}
