package com.docencia.herencia.ejercicio9;

import java.util.UUID;


public class Libro extends Producto {

    private String isbn;

    public Libro(UUID id) {
        super(id);
    }

    public Libro(UUID id, String nombre, double precio, String isbn) {
        super(id, nombre, precio);
        this.isbn = isbn;
    }

    public String getIsbn() {
        return isbn;
    }

    @Override
    public String categoria() {
        return "Libro";
    }

    @Override
    public String toString() {
        return "{Libro " + getId()
                + " isbn='" + getIsbn() + " id=" + getId()
                + "}";
    }
 @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
    if (!(obj instanceof Libro)) {
        return false;
    }
        return super.equals(obj);
    }
}
