package com.docencia.herencia.ejercicio4;

import java.util.UUID;

public class Perro extends Animal {

    private String raza;

    public Perro(UUID id) {
        super(id);
    }

    public Perro(UUID id, String nombre, String raza) {
        super(id, nombre);
        this.raza = raza;
    }

    public String getRaza() {
        return raza;
    }

    @Override
    public String sonido() {
        return "Guau";
    }

    @Override
    public String toString() {
        return "{Perro" + getNombre()
                + " raza='" + getRaza() + "id= " + getId()
                + "}";
    }
 @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
    if (!(obj instanceof Perro)) {
        return false;
    }
        return super.equals(obj);
    }
}
