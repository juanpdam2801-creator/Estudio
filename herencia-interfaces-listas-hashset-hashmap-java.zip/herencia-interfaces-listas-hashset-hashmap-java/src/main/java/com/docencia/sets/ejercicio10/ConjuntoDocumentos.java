package com.docencia.sets.ejercicio10;


import java.util.HashSet;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.UUID;

import com.docencia.herencia.ejercicio10.Documento;
import com.docencia.herencia.ejercicio10.Factura;

/**
 * Gestiona un conjunto de {@link Documento} usando internamente {@link HashSet}.
 *
 * Reglas:
 * - No se permiten elementos nulos.
 * - No se permiten elementos con campos "vacios" segun la validacion del ejercicio.
 * - No se permiten ids nulos ni duplicados.
 */
public class ConjuntoDocumentos {

    private final Set<Documento> set = new HashSet<>();

    /** Anad... un elemento a la coleccion. */
    public void anadir(Documento elemento) {
        if (set.contains(elemento)) {
            throw new IllegalArgumentException();
        }
        validar(elemento);
        set.add(elemento);
    }

    /** Busca por id. */
public Documento buscarPorId(UUID id) {
     if (id == null) {
            throw new IllegalArgumentException();
        }
        Documento DocumentoBuscar = new Factura(id);
        for (Documento Documento : set) {
            if (Documento.equals(DocumentoBuscar)) {
                return Documento;
            }
        }
        return null;
}

    /** Elimina por id. */
    public boolean eliminarPorId(UUID id) {
         Documento Documento = buscarPorId(id);
        if (Documento == null) {
            return false;
        }
        return set.remove(Documento);
    }

    /** Reemplaza el elemento con ese id por otro (mismo id). */
    public void modificar(UUID id, Documento nuevoElemento) {
       Documento existente = buscarPorId(id);
        if (existente == null) {
            throw new NoSuchElementException();
        }
        validar(nuevoElemento);
        if (!existente.equals(nuevoElemento)) {
            throw new IllegalArgumentException();
        }
        set.remove(existente);
        set.add(nuevoElemento);
    }

    /** Devuelve una copia inmutable del conjunto. */
    public Set<Documento> listar() {
         return Set.copyOf(set);
    }

    public int tamanio() {
        return set.size();
    }
    private void validar(Documento elemento) {
        if (elemento == null) {
            throw new IllegalArgumentException("El documento no puede ser nulo");
        }
        if (elemento.getId() == null) {
            throw new IllegalArgumentException("El id no puede ser nulo");
        }
        if (elemento.getTitulo() == null || elemento.getTitulo().isBlank()) {
            throw new IllegalArgumentException("El titulo no puede ser nulo o en blanco");
        }
    }

}
