package com.docencia.sets.ejercicio8;


import java.util.HashSet;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.UUID;

import com.docencia.herencia.ejercicio8.Pago;
import com.docencia.herencia.ejercicio8.PagoTarjeta;

/**
 * Gestiona un conjunto de {@link Pago} usando internamente {@link HashSet}.
 *
 * Reglas:
 * - No se permiten elementos nulos.
 * - No se permiten elementos con campos "vacios" segun la validacion del ejercicio.
 * - No se permiten ids nulos ni duplicados.
 */
public class ConjuntoPagos {

    private final Set<Pago> set = new HashSet<>();

    /** Anad... un elemento a la coleccion. */
    public void anadir(Pago elemento) {
         if (set.contains(elemento)) {
            throw new IllegalArgumentException();
        }
        validar(elemento);
        set.add(elemento);
    }

    /** Busca por id. */
public Pago buscarPorId(UUID id) {
     if (id == null) {
            throw new IllegalArgumentException();
        }
        Pago PagoBuscar = new PagoTarjeta(id);
        for (Pago Pago : set) {
            if (Pago.equals(PagoBuscar)) {
                return Pago;
            }
        }
        return null;
}

    /** Elimina por id. */
    public boolean eliminarPorId(UUID id) {
          Pago Pago = buscarPorId(id);
        if (Pago == null) {
            return false;
        }
        return set.remove(Pago);
    }

    /** Reemplaza el elemento con ese id por otro (mismo id). */
    public void modificar(UUID id, Pago nuevoElemento) {
        Pago existente = buscarPorId(id);
        if (existente == null) {
            throw new NoSuchElementException();
        }
        validar(nuevoElemento);
        if (!existente.equals(nuevoElemento)) {
            throw new IllegalArgumentException();
        }
        set.remove(existente);
        set.add(nuevoElemento);
    }

    /** Devuelve una copia inmutable del conjunto. */
    public Set<Pago> listar() {
           return Set.copyOf(set);
    }

    public int tamanio() {
           return set.size();
    }
    private void validar(Pago elemento) {
        if (elemento == null) {
            throw new IllegalArgumentException("El pago no puede ser nulo");
        }
        if (elemento.getId() == null) {
            throw new IllegalArgumentException("El id no puede ser nulo");
        }
        if (elemento.getImporte() <= 0) {
            throw new IllegalArgumentException("El importe debe ser mayor que cero");
        }
    }

}
