package com.docencia.interfaces.ejercicio9;

import java.util.Objects;
import java.util.UUID;

/**
 * Implementacion concreta de Descontable.
 */
public class Cupon implements Descontable {

    private UUID id;
    private double importe;
    private String codigo;
    public Cupon(UUID id) {
            this.id = id;
        }

    public Cupon(UUID id, double importe, String codigo) {
           this.id = id == null ? UUID.randomUUID() : id;
           this.importe = importe;
           this.codigo = codigo;
    }

    
    public UUID getId() {
        return id;
    }

    public double getImporte() {
        return importe;
    }

    public String getCodigo() {
        return codigo;
    }

    @Override
    public double aplicarDescuento(double precio) {
        return Math.max(0.0, precio - importe);
    }

    

    @Override
    public String toString() {
        return "{Cupon" +
            " id='" + getId() + "'" +
            ", importe='" + getImporte() + "'" +
            ", codigo='" + getCodigo() + "'" +
            "}";
    }

    

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 29 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Cupon other = (Cupon) obj;
        return Objects.equals(this.id, other.id);
    }
}

