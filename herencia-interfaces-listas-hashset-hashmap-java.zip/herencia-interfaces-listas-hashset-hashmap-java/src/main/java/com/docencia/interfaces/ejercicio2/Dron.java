package com.docencia.interfaces.ejercicio2;

import java.util.Objects;
import java.util.UUID;

/**
 * Implementacion concreta de Volador.
 */
public class Dron implements Volador {

    private UUID id;
    private String marca;
    private int bateriaMinutos;
    public Dron(UUID id) {
        this.id = id;
    }
    public Dron(UUID id, String marca, int bateriaMinutos) {
         this.id = id == null ? UUID.randomUUID() : id;
         this.marca = marca;
         this.bateriaMinutos = bateriaMinutos;
    }

    public UUID getId() {
        return id;
    }

    public String getMarca() {
        return marca;
    }

    public int getBateriaMinutos() {
        return bateriaMinutos;
    }

    @Override
    public int altitudMaxima() {
        return 500;
    }

    
  
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 19 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Dron other = (Dron) obj;
        return Objects.equals(this.id, other.id);
    }

    @Override
    public String toString() {
        return "{Dron" +
            " id='" + getId() + "'" +
            ", marca='" + getMarca() + "'" +
            ", bateriaMinutos='" + getBateriaMinutos() + "'" +
            "}";
    }
    
}
