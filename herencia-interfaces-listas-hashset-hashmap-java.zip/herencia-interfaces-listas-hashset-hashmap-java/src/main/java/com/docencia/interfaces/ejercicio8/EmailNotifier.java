package com.docencia.interfaces.ejercicio8;

import java.util.Objects;
import java.util.UUID;

/**
 * Implementacion concreta de Notificable.
 */
public class EmailNotifier implements Notificable {

    private UUID id;
    private String from;
    private String to;

    public EmailNotifier(UUID id) {
        this.id = id;
    }
    public EmailNotifier(UUID id, String from, String to) {
           this.id = id == null ? UUID.randomUUID() : id;
           this.from = from;
           this.to = to;
    }

    

    public UUID getId() {
        return id;
    }

    public String getFrom() {
        return from;
    }

    public String getTo() {
        return to;
    }

    @Override
    public boolean notificar(String mensaje) {
        return mensaje != null && !mensaje.isBlank() && to.contains("@");
    }

  

    @Override
    public String toString() {
        return "{EmailNotifier" +
            " id='" + getId() + "'" +
            ", from='" + getFrom() + "'" +
            ", to='" + getTo() + "'" +
            "}";
    }
   

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 47 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final EmailNotifier other = (EmailNotifier) obj;
        return Objects.equals(this.id, other.id);
    }
}
