package com.docencia.listas.ejercicio2;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.UUID;

import com.docencia.herencia.ejercicio2.Coche;
import com.docencia.herencia.ejercicio2.Vehiculo;

/**
 * Gestiona una lista de {@link Vehiculo} usando {@link java.util.ArrayList}.
 *
 * Reglas:
 * - No se permiten elementos nulos.
 * - No se permiten vehiculos con marca/modelo nulos o en blanco.
 * - No se permiten ids nulos ni duplicados dentro de la lista.
 */
public class ListaVehiculos {

    private final List<Vehiculo> vehiculos = new ArrayList<>();

    public void anadir(Vehiculo vehiculo) {
      if (vehiculos.contains(vehiculo)) {
            throw new IllegalArgumentException();
        }
        validar(vehiculo);
        vehiculos.add(vehiculo);
    }
    

    public Vehiculo buscarPorId(UUID id) {
        if (id == null) {
            throw new IllegalArgumentException();
        }
        Vehiculo vehiculoBuscar = new Coche(id);
        for (Vehiculo vehiculo : vehiculos) {
            if (vehiculo.equals(vehiculoBuscar)) {
                return vehiculo;
            }
        }
        return null;
    }

    public boolean eliminarPorId(UUID id) {
         Vehiculo vehiculo = buscarPorId(id);
        if (vehiculo == null) {
            return false;
        }
        return vehiculos.remove(vehiculo);
    }

    public void modificar(UUID id, Vehiculo nuevoVehiculo) {
        Vehiculo existente = buscarPorId(id);
        if (existente == null) {
            throw new NoSuchElementException();
        }
        validar(nuevoVehiculo);
        if (!existente.equals(nuevoVehiculo)) {
            throw new IllegalArgumentException();
        }
        vehiculos.remove(existente);
        vehiculos.add(nuevoVehiculo);
    }

    public List<Vehiculo> listar() {
      return List.copyOf(vehiculos);
    }

    public int tamanio() {
       return vehiculos.size();
    }

    private boolean existeId(UUID id) {
        return vehiculos.stream().anyMatch(v -> v.getId().equals(id));
    }

    private void validar(Vehiculo vehiculo) {
        if (vehiculo == null) {
            throw new IllegalArgumentException("El vehiculo no puede ser nulo");
        }
        if (vehiculo.getId() == null) {
            throw new IllegalArgumentException("El id no puede ser nulo");
        }
        if (vehiculo.getMarca() == null || vehiculo.getMarca().isBlank()) {
            throw new IllegalArgumentException("La marca no puede ser nula o en blanco");
        }
        if (vehiculo.getModelo() == null || vehiculo.getModelo().isBlank()) {
            throw new IllegalArgumentException("El modelo no puede ser nulo o en blanco");
        }
    }
}
