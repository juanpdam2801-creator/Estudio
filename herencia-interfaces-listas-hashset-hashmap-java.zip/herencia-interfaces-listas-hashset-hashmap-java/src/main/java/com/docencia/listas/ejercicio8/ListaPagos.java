package com.docencia.listas.ejercicio8;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.UUID;

import com.docencia.herencia.ejercicio8.Pago;
import com.docencia.herencia.ejercicio8.PagoTarjeta;

/**
 * Gestiona una lista de {@link Pago} usando {@link java.util.ArrayList}.
 *
 * Reglas: - No se permiten elementos nulos. - No se permiten pagos con importe
 * menor o igual a cero. - No se permiten ids nulos ni duplicados dentro de la
 * lista.
 */
public class ListaPagos {

    private final List<Pago> pagos = new ArrayList<>();

    public void anadir(Pago pago) {
        if (pagos.contains(pago)) {
            throw new IllegalArgumentException();
        }
        validar(pago);
        pagos.add(pago);
    }

    public Pago buscarPorId(UUID id) {
        if (id == null) {
            throw new IllegalArgumentException();
        }
        Pago pagoBuscar = new PagoTarjeta(id);
        for (Pago pago : pagos) {
            if (pago.equals(pagoBuscar)) {
                return pago;
            }
        }
        return null;
    }

    public boolean eliminarPorId(UUID id) {
        Pago pago = buscarPorId(id);
        if (pago == null) {
            return false;
        }
        return pagos.remove(pago);

    }

    public void modificar(UUID id, Pago nuevoPago) {
        Pago existente = buscarPorId(id);
        if (existente == null) {
            throw new NoSuchElementException();
        }
        validar(nuevoPago);
        if (!existente.equals(nuevoPago)) {
            throw new IllegalArgumentException();
        }
        pagos.remove(existente);
        pagos.add(nuevoPago);
    }

    public List<Pago> listar() {
        return  List.copyOf(pagos);
    }

    public int tamanio() {
        return pagos.size();
    }

    private boolean existeId(UUID id) {
        return pagos.stream().anyMatch(p -> p.getId().equals(id));
    }

    private void validar(Pago pago) {
        if (pago == null) {
            throw new IllegalArgumentException("El pago no puede ser nulo");
        }
        if (pago.getId() == null) {
            throw new IllegalArgumentException("El id no puede ser nulo");
        }
        if (pago.getImporte() <= 0) {
            throw new IllegalArgumentException("El importe debe ser mayor que cero");
        }
    }
}
